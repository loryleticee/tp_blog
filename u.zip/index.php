<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <?php include_once('./vues/templates/head.php'); ?>
  <link rel="stylesheet" href="/assets/style/main.css" />
</head>

<body>
  <?php include_once("./vues/templates/header.php");?>

  <main id="main-home">

  </main>
</body>
<?php include_once('./vues/templates/footer.php') ?>
</html>